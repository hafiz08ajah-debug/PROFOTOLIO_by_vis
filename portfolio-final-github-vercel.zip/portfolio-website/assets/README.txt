Taruh foto profil milikmu di folder ini dengan nama profile.jpg. Path yang dipakai website: assets/profile.jpg
